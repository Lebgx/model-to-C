#include "forward.h"
#include "model.h"

int main(int argc, char *argv[]){



	/******************  初始化输入张量  ******************/
	float*** singal_array;
	singal_array = alloc_3D(1, 28, 28);
	for (int i = 0; i < 1; i++) {
		for (int j = 0; j < 28; j++) {
			singal_array[i][j] = singal[i][j];
		}
	}
	Tensor* conv2d_input;
	conv2d_input = make_tensor(1, 28, 28, singal_array);


	/******************  创建各层   ******************/

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****conv2d_pw;
	conv2d_pw = alloc_4D(32, 1, 5, 5);
	for(int i = 0; i < 32; i++){
		for(int j = 0; j < 1; j++){
			for(int k = 0; k < 5; k++){
			conv2d_pw[i][j][k] = conv2d_weights[i][j][k];
			}
		}
	}
	ConvLayer *_conv2d;
	_conv2d = new_Conv(32, 1, 5, 5, conv2d_pw, &conv2d_biases, 1, 1, VALID);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****conv2d_1_pw;
	conv2d_1_pw = alloc_4D(64, 32, 5, 5);
	for(int i = 0; i < 64; i++){
		for(int j = 0; j < 32; j++){
			for(int k = 0; k < 5; k++){
			conv2d_1_pw[i][j][k] = conv2d_1_weights[i][j][k];
			}
		}
	}
	ConvLayer *_conv2d_1;
	_conv2d_1 = new_Conv(64, 32, 5, 5, conv2d_1_pw, &conv2d_1_biases, 1, 1, VALID);

	// ---------- 创建一个全连接层 ----------
	// 生成 float ****weights_array
	float ****dense_pw;
	dense_pw = alloc_4D(100, 1, 1, 1024);
	for(int i = 0; i < 100; i++){
		for(int j = 0; j < 1024; j++){
				dense_pw[i][0][0][j] = dense_weights[i][j];
		}
	}
	DenseLayer *_dense;
	_dense = new_Dense(100, 1, 1, 1024, dense_pw, &dense_biases);

	// ---------- 创建一个全连接层 ----------
	// 生成 float ****weights_array
	float ****dense_1_pw;
	dense_1_pw = alloc_4D(10, 1, 1, 100);
	for(int i = 0; i < 10; i++){
		for(int j = 0; j < 100; j++){
				dense_1_pw[i][0][0][j] = dense_1_weights[i][j];
		}
	}
	DenseLayer *_dense_1;
	_dense_1 = new_Dense(10, 1, 1, 100, dense_1_pw, &dense_1_biases);


	/******************  前向传播  ******************/
	Tensor* conv2d;
	conv2d = Conv(conv2d_input, _conv2d, ReLU_activation, 0);
	Tensor* max_pooling2d;
	max_pooling2d = MaxPool(conv2d, 2, 2, 2, 2, VALID, 0);
	Tensor* conv2d_1;
	conv2d_1 = Conv(max_pooling2d, _conv2d_1, ReLU_activation, 0);
	Tensor* max_pooling2d_1;
	max_pooling2d_1 = MaxPool(conv2d_1, 2, 2, 2, 2, VALID, 0);
	Tensor* flatten;
	flatten = FlattenW(max_pooling2d_1, 0);
	Tensor* dense;
	dense = Dense(flatten, _dense, ReLU_activation, 0);
	Tensor* dense_1;
	dense_1 = Dense(dense, _dense_1, softmax_activation, 0);


	//print_tensor(conv2d_input);


	/******************  释放内存  ******************/
	free_ConvLayer(_conv2d);
	free_ConvLayer(_conv2d_1);
	free_DenseLayer(_dense);
	free_DenseLayer(_dense_1);

	printf("\nHello World!\n");
	return 0;
}