#include "forward.h"
#include "model.h"

int main(int argc, char *argv[]){



	/******************  初始化输入张量  ******************/
	float*** singal_array;
	singal_array = alloc_3D(1, 1, 256);
	for (int i = 0; i < 1; i++) {
		singal_array[i][0] = singal[i];
	}
	Tensor* main_input;
	main_input = make_tensor(1, 1, 256, singal_array);


	/******************  创建各层   ******************/

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x11_1_conv_down_pw;
	x11_1_conv_down_pw = alloc_4D(4, 1, 1, 1);
	for(int i = 0; i < 4; i++){
		for(int j = 0; j < 1; j++){
			x11_1_conv_down_pw[i][j][0] = x11_1_conv_down_weights[i][j];
		}
	}
	ConvLayer *_x11_1_conv_down;
	_x11_1_conv_down = new_Conv(4, 1, 1, 1, x11_1_conv_down_pw, &x11_1_conv_down_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x11_2_0_conv_pw;
	x11_2_0_conv_pw = alloc_4D(4, 4, 1, 7);
	for(int i = 0; i < 4; i++){
		for(int j = 0; j < 4; j++){
			x11_2_0_conv_pw[i][j][0] = x11_2_0_conv_weights[i][j];
		}
	}
	ConvLayer *_x11_2_0_conv;
	_x11_2_0_conv = new_Conv(4, 4, 1, 7, x11_2_0_conv_pw, &x11_2_0_conv_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x11_3_conv_up_pw;
	x11_3_conv_up_pw = alloc_4D(16, 4, 1, 1);
	for(int i = 0; i < 16; i++){
		for(int j = 0; j < 4; j++){
			x11_3_conv_up_pw[i][j][0] = x11_3_conv_up_weights[i][j];
		}
	}
	ConvLayer *_x11_3_conv_up;
	_x11_3_conv_up = new_Conv(16, 4, 1, 1, x11_3_conv_up_pw, &x11_3_conv_up_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x11_4_shortcut_pw;
	x11_4_shortcut_pw = alloc_4D(16, 1, 1, 1);
	for(int i = 0; i < 16; i++){
		for(int j = 0; j < 1; j++){
			x11_4_shortcut_pw[i][j][0] = x11_4_shortcut_weights[i][j];
		}
	}
	ConvLayer *_x11_4_shortcut;
	_x11_4_shortcut = new_Conv(16, 1, 1, 1, x11_4_shortcut_pw, &x11_4_shortcut_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x21_1_conv_down_pw;
	x21_1_conv_down_pw = alloc_4D(8, 16, 1, 1);
	for(int i = 0; i < 8; i++){
		for(int j = 0; j < 16; j++){
			x21_1_conv_down_pw[i][j][0] = x21_1_conv_down_weights[i][j];
		}
	}
	ConvLayer *_x21_1_conv_down;
	_x21_1_conv_down = new_Conv(8, 16, 1, 1, x21_1_conv_down_pw, &x21_1_conv_down_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x21_2_0_conv_pw;
	x21_2_0_conv_pw = alloc_4D(8, 8, 1, 5);
	for(int i = 0; i < 8; i++){
		for(int j = 0; j < 8; j++){
			x21_2_0_conv_pw[i][j][0] = x21_2_0_conv_weights[i][j];
		}
	}
	ConvLayer *_x21_2_0_conv;
	_x21_2_0_conv = new_Conv(8, 8, 1, 5, x21_2_0_conv_pw, &x21_2_0_conv_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x21_3_conv_up_pw;
	x21_3_conv_up_pw = alloc_4D(32, 8, 1, 1);
	for(int i = 0; i < 32; i++){
		for(int j = 0; j < 8; j++){
			x21_3_conv_up_pw[i][j][0] = x21_3_conv_up_weights[i][j];
		}
	}
	ConvLayer *_x21_3_conv_up;
	_x21_3_conv_up = new_Conv(32, 8, 1, 1, x21_3_conv_up_pw, &x21_3_conv_up_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x21_4_shortcut_pw;
	x21_4_shortcut_pw = alloc_4D(32, 16, 1, 1);
	for(int i = 0; i < 32; i++){
		for(int j = 0; j < 16; j++){
			x21_4_shortcut_pw[i][j][0] = x21_4_shortcut_weights[i][j];
		}
	}
	ConvLayer *_x21_4_shortcut;
	_x21_4_shortcut = new_Conv(32, 16, 1, 1, x21_4_shortcut_pw, &x21_4_shortcut_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x31_1_conv_down_pw;
	x31_1_conv_down_pw = alloc_4D(16, 32, 1, 1);
	for(int i = 0; i < 16; i++){
		for(int j = 0; j < 32; j++){
			x31_1_conv_down_pw[i][j][0] = x31_1_conv_down_weights[i][j];
		}
	}
	ConvLayer *_x31_1_conv_down;
	_x31_1_conv_down = new_Conv(16, 32, 1, 1, x31_1_conv_down_pw, &x31_1_conv_down_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x31_2_0_conv_pw;
	x31_2_0_conv_pw = alloc_4D(16, 16, 1, 3);
	for(int i = 0; i < 16; i++){
		for(int j = 0; j < 16; j++){
			x31_2_0_conv_pw[i][j][0] = x31_2_0_conv_weights[i][j];
		}
	}
	ConvLayer *_x31_2_0_conv;
	_x31_2_0_conv = new_Conv(16, 16, 1, 3, x31_2_0_conv_pw, &x31_2_0_conv_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x31_3_conv_up_pw;
	x31_3_conv_up_pw = alloc_4D(64, 16, 1, 1);
	for(int i = 0; i < 64; i++){
		for(int j = 0; j < 16; j++){
			x31_3_conv_up_pw[i][j][0] = x31_3_conv_up_weights[i][j];
		}
	}
	ConvLayer *_x31_3_conv_up;
	_x31_3_conv_up = new_Conv(64, 16, 1, 1, x31_3_conv_up_pw, &x31_3_conv_up_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x31_4_shortcut_pw;
	x31_4_shortcut_pw = alloc_4D(64, 32, 1, 1);
	for(int i = 0; i < 64; i++){
		for(int j = 0; j < 32; j++){
			x31_4_shortcut_pw[i][j][0] = x31_4_shortcut_weights[i][j];
		}
	}
	ConvLayer *_x31_4_shortcut;
	_x31_4_shortcut = new_Conv(64, 32, 1, 1, x31_4_shortcut_pw, &x31_4_shortcut_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x41_1_conv_down_pw;
	x41_1_conv_down_pw = alloc_4D(32, 64, 1, 1);
	for(int i = 0; i < 32; i++){
		for(int j = 0; j < 64; j++){
			x41_1_conv_down_pw[i][j][0] = x41_1_conv_down_weights[i][j];
		}
	}
	ConvLayer *_x41_1_conv_down;
	_x41_1_conv_down = new_Conv(32, 64, 1, 1, x41_1_conv_down_pw, &x41_1_conv_down_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x41_2_0_conv_pw;
	x41_2_0_conv_pw = alloc_4D(32, 32, 1, 3);
	for(int i = 0; i < 32; i++){
		for(int j = 0; j < 32; j++){
			x41_2_0_conv_pw[i][j][0] = x41_2_0_conv_weights[i][j];
		}
	}
	ConvLayer *_x41_2_0_conv;
	_x41_2_0_conv = new_Conv(32, 32, 1, 3, x41_2_0_conv_pw, &x41_2_0_conv_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x41_3_conv_up_pw;
	x41_3_conv_up_pw = alloc_4D(128, 32, 1, 1);
	for(int i = 0; i < 128; i++){
		for(int j = 0; j < 32; j++){
			x41_3_conv_up_pw[i][j][0] = x41_3_conv_up_weights[i][j];
		}
	}
	ConvLayer *_x41_3_conv_up;
	_x41_3_conv_up = new_Conv(128, 32, 1, 1, x41_3_conv_up_pw, &x41_3_conv_up_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x41_4_shortcut_pw;
	x41_4_shortcut_pw = alloc_4D(128, 64, 1, 1);
	for(int i = 0; i < 128; i++){
		for(int j = 0; j < 64; j++){
			x41_4_shortcut_pw[i][j][0] = x41_4_shortcut_weights[i][j];
		}
	}
	ConvLayer *_x41_4_shortcut;
	_x41_4_shortcut = new_Conv(128, 64, 1, 1, x41_4_shortcut_pw, &x41_4_shortcut_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x32_1_conv_down_pw;
	x32_1_conv_down_pw = alloc_4D(16, 192, 1, 1);
	for(int i = 0; i < 16; i++){
		for(int j = 0; j < 192; j++){
			x32_1_conv_down_pw[i][j][0] = x32_1_conv_down_weights[i][j];
		}
	}
	ConvLayer *_x32_1_conv_down;
	_x32_1_conv_down = new_Conv(16, 192, 1, 1, x32_1_conv_down_pw, &x32_1_conv_down_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x22_1_conv_down_pw;
	x22_1_conv_down_pw = alloc_4D(8, 96, 1, 1);
	for(int i = 0; i < 8; i++){
		for(int j = 0; j < 96; j++){
			x22_1_conv_down_pw[i][j][0] = x22_1_conv_down_weights[i][j];
		}
	}
	ConvLayer *_x22_1_conv_down;
	_x22_1_conv_down = new_Conv(8, 96, 1, 1, x22_1_conv_down_pw, &x22_1_conv_down_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x12_1_conv_down_pw;
	x12_1_conv_down_pw = alloc_4D(4, 48, 1, 1);
	for(int i = 0; i < 4; i++){
		for(int j = 0; j < 48; j++){
			x12_1_conv_down_pw[i][j][0] = x12_1_conv_down_weights[i][j];
		}
	}
	ConvLayer *_x12_1_conv_down;
	_x12_1_conv_down = new_Conv(4, 48, 1, 1, x12_1_conv_down_pw, &x12_1_conv_down_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x32_2_0_conv_pw;
	x32_2_0_conv_pw = alloc_4D(16, 16, 1, 5);
	for(int i = 0; i < 16; i++){
		for(int j = 0; j < 16; j++){
			x32_2_0_conv_pw[i][j][0] = x32_2_0_conv_weights[i][j];
		}
	}
	ConvLayer *_x32_2_0_conv;
	_x32_2_0_conv = new_Conv(16, 16, 1, 5, x32_2_0_conv_pw, &x32_2_0_conv_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x22_2_0_conv_pw;
	x22_2_0_conv_pw = alloc_4D(8, 8, 1, 5);
	for(int i = 0; i < 8; i++){
		for(int j = 0; j < 8; j++){
			x22_2_0_conv_pw[i][j][0] = x22_2_0_conv_weights[i][j];
		}
	}
	ConvLayer *_x22_2_0_conv;
	_x22_2_0_conv = new_Conv(8, 8, 1, 5, x22_2_0_conv_pw, &x22_2_0_conv_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x12_2_0_conv_pw;
	x12_2_0_conv_pw = alloc_4D(4, 4, 1, 5);
	for(int i = 0; i < 4; i++){
		for(int j = 0; j < 4; j++){
			x12_2_0_conv_pw[i][j][0] = x12_2_0_conv_weights[i][j];
		}
	}
	ConvLayer *_x12_2_0_conv;
	_x12_2_0_conv = new_Conv(4, 4, 1, 5, x12_2_0_conv_pw, &x12_2_0_conv_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x32_3_conv_up_pw;
	x32_3_conv_up_pw = alloc_4D(64, 16, 1, 1);
	for(int i = 0; i < 64; i++){
		for(int j = 0; j < 16; j++){
			x32_3_conv_up_pw[i][j][0] = x32_3_conv_up_weights[i][j];
		}
	}
	ConvLayer *_x32_3_conv_up;
	_x32_3_conv_up = new_Conv(64, 16, 1, 1, x32_3_conv_up_pw, &x32_3_conv_up_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x22_3_conv_up_pw;
	x22_3_conv_up_pw = alloc_4D(32, 8, 1, 1);
	for(int i = 0; i < 32; i++){
		for(int j = 0; j < 8; j++){
			x22_3_conv_up_pw[i][j][0] = x22_3_conv_up_weights[i][j];
		}
	}
	ConvLayer *_x22_3_conv_up;
	_x22_3_conv_up = new_Conv(32, 8, 1, 1, x22_3_conv_up_pw, &x22_3_conv_up_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x12_3_conv_up_pw;
	x12_3_conv_up_pw = alloc_4D(16, 4, 1, 1);
	for(int i = 0; i < 16; i++){
		for(int j = 0; j < 4; j++){
			x12_3_conv_up_pw[i][j][0] = x12_3_conv_up_weights[i][j];
		}
	}
	ConvLayer *_x12_3_conv_up;
	_x12_3_conv_up = new_Conv(16, 4, 1, 1, x12_3_conv_up_pw, &x12_3_conv_up_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x32_4_shortcut_pw;
	x32_4_shortcut_pw = alloc_4D(64, 192, 1, 1);
	for(int i = 0; i < 64; i++){
		for(int j = 0; j < 192; j++){
			x32_4_shortcut_pw[i][j][0] = x32_4_shortcut_weights[i][j];
		}
	}
	ConvLayer *_x32_4_shortcut;
	_x32_4_shortcut = new_Conv(64, 192, 1, 1, x32_4_shortcut_pw, &x32_4_shortcut_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x22_4_shortcut_pw;
	x22_4_shortcut_pw = alloc_4D(32, 96, 1, 1);
	for(int i = 0; i < 32; i++){
		for(int j = 0; j < 96; j++){
			x22_4_shortcut_pw[i][j][0] = x22_4_shortcut_weights[i][j];
		}
	}
	ConvLayer *_x22_4_shortcut;
	_x22_4_shortcut = new_Conv(32, 96, 1, 1, x22_4_shortcut_pw, &x22_4_shortcut_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x12_4_shortcut_pw;
	x12_4_shortcut_pw = alloc_4D(16, 48, 1, 1);
	for(int i = 0; i < 16; i++){
		for(int j = 0; j < 48; j++){
			x12_4_shortcut_pw[i][j][0] = x12_4_shortcut_weights[i][j];
		}
	}
	ConvLayer *_x12_4_shortcut;
	_x12_4_shortcut = new_Conv(16, 48, 1, 1, x12_4_shortcut_pw, &x12_4_shortcut_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x23_1_conv_down_pw;
	x23_1_conv_down_pw = alloc_4D(8, 128, 1, 1);
	for(int i = 0; i < 8; i++){
		for(int j = 0; j < 128; j++){
			x23_1_conv_down_pw[i][j][0] = x23_1_conv_down_weights[i][j];
		}
	}
	ConvLayer *_x23_1_conv_down;
	_x23_1_conv_down = new_Conv(8, 128, 1, 1, x23_1_conv_down_pw, &x23_1_conv_down_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x13_1_conv_down_pw;
	x13_1_conv_down_pw = alloc_4D(4, 64, 1, 1);
	for(int i = 0; i < 4; i++){
		for(int j = 0; j < 64; j++){
			x13_1_conv_down_pw[i][j][0] = x13_1_conv_down_weights[i][j];
		}
	}
	ConvLayer *_x13_1_conv_down;
	_x13_1_conv_down = new_Conv(4, 64, 1, 1, x13_1_conv_down_pw, &x13_1_conv_down_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x23_2_0_conv_pw;
	x23_2_0_conv_pw = alloc_4D(8, 8, 1, 3);
	for(int i = 0; i < 8; i++){
		for(int j = 0; j < 8; j++){
			x23_2_0_conv_pw[i][j][0] = x23_2_0_conv_weights[i][j];
		}
	}
	ConvLayer *_x23_2_0_conv;
	_x23_2_0_conv = new_Conv(8, 8, 1, 3, x23_2_0_conv_pw, &x23_2_0_conv_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x13_2_0_conv_pw;
	x13_2_0_conv_pw = alloc_4D(4, 4, 1, 3);
	for(int i = 0; i < 4; i++){
		for(int j = 0; j < 4; j++){
			x13_2_0_conv_pw[i][j][0] = x13_2_0_conv_weights[i][j];
		}
	}
	ConvLayer *_x13_2_0_conv;
	_x13_2_0_conv = new_Conv(4, 4, 1, 3, x13_2_0_conv_pw, &x13_2_0_conv_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x23_3_conv_up_pw;
	x23_3_conv_up_pw = alloc_4D(32, 8, 1, 1);
	for(int i = 0; i < 32; i++){
		for(int j = 0; j < 8; j++){
			x23_3_conv_up_pw[i][j][0] = x23_3_conv_up_weights[i][j];
		}
	}
	ConvLayer *_x23_3_conv_up;
	_x23_3_conv_up = new_Conv(32, 8, 1, 1, x23_3_conv_up_pw, &x23_3_conv_up_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x13_3_conv_up_pw;
	x13_3_conv_up_pw = alloc_4D(16, 4, 1, 1);
	for(int i = 0; i < 16; i++){
		for(int j = 0; j < 4; j++){
			x13_3_conv_up_pw[i][j][0] = x13_3_conv_up_weights[i][j];
		}
	}
	ConvLayer *_x13_3_conv_up;
	_x13_3_conv_up = new_Conv(16, 4, 1, 1, x13_3_conv_up_pw, &x13_3_conv_up_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x23_4_shortcut_pw;
	x23_4_shortcut_pw = alloc_4D(32, 128, 1, 1);
	for(int i = 0; i < 32; i++){
		for(int j = 0; j < 128; j++){
			x23_4_shortcut_pw[i][j][0] = x23_4_shortcut_weights[i][j];
		}
	}
	ConvLayer *_x23_4_shortcut;
	_x23_4_shortcut = new_Conv(32, 128, 1, 1, x23_4_shortcut_pw, &x23_4_shortcut_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x13_4_shortcut_pw;
	x13_4_shortcut_pw = alloc_4D(16, 64, 1, 1);
	for(int i = 0; i < 16; i++){
		for(int j = 0; j < 64; j++){
			x13_4_shortcut_pw[i][j][0] = x13_4_shortcut_weights[i][j];
		}
	}
	ConvLayer *_x13_4_shortcut;
	_x13_4_shortcut = new_Conv(16, 64, 1, 1, x13_4_shortcut_pw, &x13_4_shortcut_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x14_1_conv_down_pw;
	x14_1_conv_down_pw = alloc_4D(4, 80, 1, 1);
	for(int i = 0; i < 4; i++){
		for(int j = 0; j < 80; j++){
			x14_1_conv_down_pw[i][j][0] = x14_1_conv_down_weights[i][j];
		}
	}
	ConvLayer *_x14_1_conv_down;
	_x14_1_conv_down = new_Conv(4, 80, 1, 1, x14_1_conv_down_pw, &x14_1_conv_down_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x14_2_0_conv_pw;
	x14_2_0_conv_pw = alloc_4D(4, 4, 1, 3);
	for(int i = 0; i < 4; i++){
		for(int j = 0; j < 4; j++){
			x14_2_0_conv_pw[i][j][0] = x14_2_0_conv_weights[i][j];
		}
	}
	ConvLayer *_x14_2_0_conv;
	_x14_2_0_conv = new_Conv(4, 4, 1, 3, x14_2_0_conv_pw, &x14_2_0_conv_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x14_3_conv_up_pw;
	x14_3_conv_up_pw = alloc_4D(16, 4, 1, 1);
	for(int i = 0; i < 16; i++){
		for(int j = 0; j < 4; j++){
			x14_3_conv_up_pw[i][j][0] = x14_3_conv_up_weights[i][j];
		}
	}
	ConvLayer *_x14_3_conv_up;
	_x14_3_conv_up = new_Conv(16, 4, 1, 1, x14_3_conv_up_pw, &x14_3_conv_up_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****x14_4_shortcut_pw;
	x14_4_shortcut_pw = alloc_4D(16, 80, 1, 1);
	for(int i = 0; i < 16; i++){
		for(int j = 0; j < 80; j++){
			x14_4_shortcut_pw[i][j][0] = x14_4_shortcut_weights[i][j];
		}
	}
	ConvLayer *_x14_4_shortcut;
	_x14_4_shortcut = new_Conv(16, 80, 1, 1, x14_4_shortcut_pw, &x14_4_shortcut_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****main_output_1_pw;
	main_output_1_pw = alloc_4D(1, 16, 1, 1);
	for(int i = 0; i < 1; i++){
		for(int j = 0; j < 16; j++){
			main_output_1_pw[i][j][0] = main_output_1_weights[i][j];
		}
	}
	ConvLayer *_main_output_1;
	_main_output_1 = new_Conv(1, 16, 1, 1, main_output_1_pw, &main_output_1_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****main_output_2_pw;
	main_output_2_pw = alloc_4D(1, 16, 1, 1);
	for(int i = 0; i < 1; i++){
		for(int j = 0; j < 16; j++){
			main_output_2_pw[i][j][0] = main_output_2_weights[i][j];
		}
	}
	ConvLayer *_main_output_2;
	_main_output_2 = new_Conv(1, 16, 1, 1, main_output_2_pw, &main_output_2_biases, 1, 1, SAME);

	// ---------- 创建一个卷积层 ----------
	// 生成 float ****weights_array
	float ****main_output_3_pw;
	main_output_3_pw = alloc_4D(1, 16, 1, 1);
	for(int i = 0; i < 1; i++){
		for(int j = 0; j < 16; j++){
			main_output_3_pw[i][j][0] = main_output_3_weights[i][j];
		}
	}
	ConvLayer *_main_output_3;
	_main_output_3 = new_Conv(1, 16, 1, 1, main_output_3_pw, &main_output_3_biases, 1, 1, SAME);


	/******************  前向传播  ******************/
	Tensor* x11_1_conv_down;
	x11_1_conv_down = Conv(main_input, _x11_1_conv_down, linear_activation, 0);
	Tensor* x11_1_batch;
	float(*x11_1_batch_pg)[4];
	x11_1_batch_pg=x11_1_batch_gamma;
	float(*x11_1_batch_pb)[4];
	x11_1_batch_pb=x11_1_batch_beta;
	float(*x11_1_batch_pm)[4];
	x11_1_batch_pm=x11_1_batch_moving_mean;
	float(*x11_1_batch_pv)[4];
	x11_1_batch_pv=x11_1_batch_moving_variance;
	x11_1_batch = BatchNormalization(x11_1_conv_down, &x11_1_batch_pg, &x11_1_batch_pb, &x11_1_batch_pm, &x11_1_batch_pv, 0);
	Tensor* x11_1_relu;
	x11_1_relu = ReLU_activation(x11_1_batch, 0);
	Tensor* x11_2_0_conv;
	x11_2_0_conv = Conv(x11_1_relu, _x11_2_0_conv, linear_activation, 0);
	Tensor* x11_2_0_batch;
	float(*x11_2_0_batch_pg)[4];
	x11_2_0_batch_pg=x11_2_0_batch_gamma;
	float(*x11_2_0_batch_pb)[4];
	x11_2_0_batch_pb=x11_2_0_batch_beta;
	float(*x11_2_0_batch_pm)[4];
	x11_2_0_batch_pm=x11_2_0_batch_moving_mean;
	float(*x11_2_0_batch_pv)[4];
	x11_2_0_batch_pv=x11_2_0_batch_moving_variance;
	x11_2_0_batch = BatchNormalization(x11_2_0_conv, &x11_2_0_batch_pg, &x11_2_0_batch_pb, &x11_2_0_batch_pm, &x11_2_0_batch_pv, 0);
	Tensor* x11_2_0_relu;
	x11_2_0_relu = ReLU_activation(x11_2_0_batch, 0);
	Tensor* x11_3_conv_up;
	x11_3_conv_up = Conv(x11_2_0_relu, _x11_3_conv_up, linear_activation, 0);
	Tensor* x11_3_batch;
	float(*x11_3_batch_pg)[16];
	x11_3_batch_pg=x11_3_batch_gamma;
	float(*x11_3_batch_pb)[16];
	x11_3_batch_pb=x11_3_batch_beta;
	float(*x11_3_batch_pm)[16];
	x11_3_batch_pm=x11_3_batch_moving_mean;
	float(*x11_3_batch_pv)[16];
	x11_3_batch_pv=x11_3_batch_moving_variance;
	x11_3_batch = BatchNormalization(x11_3_conv_up, &x11_3_batch_pg, &x11_3_batch_pb, &x11_3_batch_pm, &x11_3_batch_pv, 0);
	Tensor* x11_3_relu;
	x11_3_relu = ReLU_activation(x11_3_batch, 0);
	Tensor* x11_4_shortcut;
	x11_4_shortcut = Conv(main_input, _x11_4_shortcut, linear_activation, 0);
	Tensor* x11_4_relu;
	x11_4_relu = ReLU_activation(x11_3_relu, 0);
	Tensor* x11_4_batch;
	float(*x11_4_batch_pg)[16];
	x11_4_batch_pg=x11_4_batch_gamma;
	float(*x11_4_batch_pb)[16];
	x11_4_batch_pb=x11_4_batch_beta;
	float(*x11_4_batch_pm)[16];
	x11_4_batch_pm=x11_4_batch_moving_mean;
	float(*x11_4_batch_pv)[16];
	x11_4_batch_pv=x11_4_batch_moving_variance;
	x11_4_batch = BatchNormalization(x11_4_shortcut, &x11_4_batch_pg, &x11_4_batch_pb, &x11_4_batch_pm, &x11_4_batch_pv, 0);
	Tensor* x11_5_add;
	x11_5_add = Add(x11_4_relu, x11_4_batch, 0);
	Tensor* x11_5_relu;
	x11_5_relu = ReLU_activation(x11_5_add, 0);
	Tensor* x11_batch;
	float(*x11_batch_pg)[16];
	x11_batch_pg=x11_batch_gamma;
	float(*x11_batch_pb)[16];
	x11_batch_pb=x11_batch_beta;
	float(*x11_batch_pm)[16];
	x11_batch_pm=x11_batch_moving_mean;
	float(*x11_batch_pv)[16];
	x11_batch_pv=x11_batch_moving_variance;
	x11_batch = BatchNormalization(x11_5_relu, &x11_batch_pg, &x11_batch_pb, &x11_batch_pm, &x11_batch_pv, 0);
	Tensor* x21_Maxpool;
	x21_Maxpool = MaxPool(x11_batch, 1, 2, 2, 1, VALID, 0);
	Tensor* x21_1_conv_down;
	x21_1_conv_down = Conv(x21_Maxpool, _x21_1_conv_down, linear_activation, 0);
	Tensor* x21_1_batch;
	float(*x21_1_batch_pg)[8];
	x21_1_batch_pg=x21_1_batch_gamma;
	float(*x21_1_batch_pb)[8];
	x21_1_batch_pb=x21_1_batch_beta;
	float(*x21_1_batch_pm)[8];
	x21_1_batch_pm=x21_1_batch_moving_mean;
	float(*x21_1_batch_pv)[8];
	x21_1_batch_pv=x21_1_batch_moving_variance;
	x21_1_batch = BatchNormalization(x21_1_conv_down, &x21_1_batch_pg, &x21_1_batch_pb, &x21_1_batch_pm, &x21_1_batch_pv, 0);
	Tensor* x21_1_relu;
	x21_1_relu = ReLU_activation(x21_1_batch, 0);
	Tensor* x21_2_0_conv;
	x21_2_0_conv = Conv(x21_1_relu, _x21_2_0_conv, linear_activation, 0);
	Tensor* x21_2_0_batch;
	float(*x21_2_0_batch_pg)[8];
	x21_2_0_batch_pg=x21_2_0_batch_gamma;
	float(*x21_2_0_batch_pb)[8];
	x21_2_0_batch_pb=x21_2_0_batch_beta;
	float(*x21_2_0_batch_pm)[8];
	x21_2_0_batch_pm=x21_2_0_batch_moving_mean;
	float(*x21_2_0_batch_pv)[8];
	x21_2_0_batch_pv=x21_2_0_batch_moving_variance;
	x21_2_0_batch = BatchNormalization(x21_2_0_conv, &x21_2_0_batch_pg, &x21_2_0_batch_pb, &x21_2_0_batch_pm, &x21_2_0_batch_pv, 0);
	Tensor* x21_2_0_relu;
	x21_2_0_relu = ReLU_activation(x21_2_0_batch, 0);
	Tensor* x21_3_conv_up;
	x21_3_conv_up = Conv(x21_2_0_relu, _x21_3_conv_up, linear_activation, 0);
	Tensor* x21_3_batch;
	float(*x21_3_batch_pg)[32];
	x21_3_batch_pg=x21_3_batch_gamma;
	float(*x21_3_batch_pb)[32];
	x21_3_batch_pb=x21_3_batch_beta;
	float(*x21_3_batch_pm)[32];
	x21_3_batch_pm=x21_3_batch_moving_mean;
	float(*x21_3_batch_pv)[32];
	x21_3_batch_pv=x21_3_batch_moving_variance;
	x21_3_batch = BatchNormalization(x21_3_conv_up, &x21_3_batch_pg, &x21_3_batch_pb, &x21_3_batch_pm, &x21_3_batch_pv, 0);
	Tensor* x21_3_relu;
	x21_3_relu = ReLU_activation(x21_3_batch, 0);
	Tensor* x21_4_shortcut;
	x21_4_shortcut = Conv(x21_Maxpool, _x21_4_shortcut, linear_activation, 0);
	Tensor* x21_4_relu;
	x21_4_relu = ReLU_activation(x21_3_relu, 0);
	Tensor* x21_4_batch;
	float(*x21_4_batch_pg)[32];
	x21_4_batch_pg=x21_4_batch_gamma;
	float(*x21_4_batch_pb)[32];
	x21_4_batch_pb=x21_4_batch_beta;
	float(*x21_4_batch_pm)[32];
	x21_4_batch_pm=x21_4_batch_moving_mean;
	float(*x21_4_batch_pv)[32];
	x21_4_batch_pv=x21_4_batch_moving_variance;
	x21_4_batch = BatchNormalization(x21_4_shortcut, &x21_4_batch_pg, &x21_4_batch_pb, &x21_4_batch_pm, &x21_4_batch_pv, 0);
	Tensor* x21_5_add;
	x21_5_add = Add(x21_4_relu, x21_4_batch, 0);
	Tensor* x21_5_relu;
	x21_5_relu = ReLU_activation(x21_5_add, 0);
	Tensor* x21_batch;
	float(*x21_batch_pg)[32];
	x21_batch_pg=x21_batch_gamma;
	float(*x21_batch_pb)[32];
	x21_batch_pb=x21_batch_beta;
	float(*x21_batch_pm)[32];
	x21_batch_pm=x21_batch_moving_mean;
	float(*x21_batch_pv)[32];
	x21_batch_pv=x21_batch_moving_variance;
	x21_batch = BatchNormalization(x21_5_relu, &x21_batch_pg, &x21_batch_pb, &x21_batch_pm, &x21_batch_pv, 0);
	Tensor* x21_Dropout;
	x21_Dropout = x21_batch;
	Tensor* x31_Maxpool;
	x31_Maxpool = MaxPool(x21_Dropout, 1, 2, 2, 1, VALID, 0);
	Tensor* x31_1_conv_down;
	x31_1_conv_down = Conv(x31_Maxpool, _x31_1_conv_down, linear_activation, 0);
	Tensor* x31_1_batch;
	float(*x31_1_batch_pg)[16];
	x31_1_batch_pg=x31_1_batch_gamma;
	float(*x31_1_batch_pb)[16];
	x31_1_batch_pb=x31_1_batch_beta;
	float(*x31_1_batch_pm)[16];
	x31_1_batch_pm=x31_1_batch_moving_mean;
	float(*x31_1_batch_pv)[16];
	x31_1_batch_pv=x31_1_batch_moving_variance;
	x31_1_batch = BatchNormalization(x31_1_conv_down, &x31_1_batch_pg, &x31_1_batch_pb, &x31_1_batch_pm, &x31_1_batch_pv, 0);
	Tensor* x31_1_relu;
	x31_1_relu = ReLU_activation(x31_1_batch, 0);
	Tensor* x31_2_0_conv;
	x31_2_0_conv = Conv(x31_1_relu, _x31_2_0_conv, linear_activation, 0);
	Tensor* x31_2_0_batch;
	float(*x31_2_0_batch_pg)[16];
	x31_2_0_batch_pg=x31_2_0_batch_gamma;
	float(*x31_2_0_batch_pb)[16];
	x31_2_0_batch_pb=x31_2_0_batch_beta;
	float(*x31_2_0_batch_pm)[16];
	x31_2_0_batch_pm=x31_2_0_batch_moving_mean;
	float(*x31_2_0_batch_pv)[16];
	x31_2_0_batch_pv=x31_2_0_batch_moving_variance;
	x31_2_0_batch = BatchNormalization(x31_2_0_conv, &x31_2_0_batch_pg, &x31_2_0_batch_pb, &x31_2_0_batch_pm, &x31_2_0_batch_pv, 0);
	Tensor* x31_2_0_relu;
	x31_2_0_relu = ReLU_activation(x31_2_0_batch, 0);
	Tensor* x31_3_conv_up;
	x31_3_conv_up = Conv(x31_2_0_relu, _x31_3_conv_up, linear_activation, 0);
	Tensor* x31_3_batch;
	float(*x31_3_batch_pg)[64];
	x31_3_batch_pg=x31_3_batch_gamma;
	float(*x31_3_batch_pb)[64];
	x31_3_batch_pb=x31_3_batch_beta;
	float(*x31_3_batch_pm)[64];
	x31_3_batch_pm=x31_3_batch_moving_mean;
	float(*x31_3_batch_pv)[64];
	x31_3_batch_pv=x31_3_batch_moving_variance;
	x31_3_batch = BatchNormalization(x31_3_conv_up, &x31_3_batch_pg, &x31_3_batch_pb, &x31_3_batch_pm, &x31_3_batch_pv, 0);
	Tensor* x31_3_relu;
	x31_3_relu = ReLU_activation(x31_3_batch, 0);
	Tensor* x31_4_shortcut;
	x31_4_shortcut = Conv(x31_Maxpool, _x31_4_shortcut, linear_activation, 0);
	Tensor* x31_4_relu;
	x31_4_relu = ReLU_activation(x31_3_relu, 0);
	Tensor* x31_4_batch;
	float(*x31_4_batch_pg)[64];
	x31_4_batch_pg=x31_4_batch_gamma;
	float(*x31_4_batch_pb)[64];
	x31_4_batch_pb=x31_4_batch_beta;
	float(*x31_4_batch_pm)[64];
	x31_4_batch_pm=x31_4_batch_moving_mean;
	float(*x31_4_batch_pv)[64];
	x31_4_batch_pv=x31_4_batch_moving_variance;
	x31_4_batch = BatchNormalization(x31_4_shortcut, &x31_4_batch_pg, &x31_4_batch_pb, &x31_4_batch_pm, &x31_4_batch_pv, 0);
	Tensor* x31_5_add;
	x31_5_add = Add(x31_4_relu, x31_4_batch, 0);
	Tensor* x31_5_relu;
	x31_5_relu = ReLU_activation(x31_5_add, 0);
	Tensor* x31_batch;
	float(*x31_batch_pg)[64];
	x31_batch_pg=x31_batch_gamma;
	float(*x31_batch_pb)[64];
	x31_batch_pb=x31_batch_beta;
	float(*x31_batch_pm)[64];
	x31_batch_pm=x31_batch_moving_mean;
	float(*x31_batch_pv)[64];
	x31_batch_pv=x31_batch_moving_variance;
	x31_batch = BatchNormalization(x31_5_relu, &x31_batch_pg, &x31_batch_pb, &x31_batch_pm, &x31_batch_pv, 0);
	Tensor* x41_Maxpool;
	x41_Maxpool = MaxPool(x31_batch, 1, 2, 2, 1, VALID, 0);
	Tensor* x41_1_conv_down;
	x41_1_conv_down = Conv(x41_Maxpool, _x41_1_conv_down, linear_activation, 0);
	Tensor* x41_1_batch;
	float(*x41_1_batch_pg)[32];
	x41_1_batch_pg=x41_1_batch_gamma;
	float(*x41_1_batch_pb)[32];
	x41_1_batch_pb=x41_1_batch_beta;
	float(*x41_1_batch_pm)[32];
	x41_1_batch_pm=x41_1_batch_moving_mean;
	float(*x41_1_batch_pv)[32];
	x41_1_batch_pv=x41_1_batch_moving_variance;
	x41_1_batch = BatchNormalization(x41_1_conv_down, &x41_1_batch_pg, &x41_1_batch_pb, &x41_1_batch_pm, &x41_1_batch_pv, 0);
	Tensor* x41_1_relu;
	x41_1_relu = ReLU_activation(x41_1_batch, 0);
	Tensor* x41_2_0_conv;
	x41_2_0_conv = Conv(x41_1_relu, _x41_2_0_conv, linear_activation, 0);
	Tensor* x41_2_0_batch;
	float(*x41_2_0_batch_pg)[32];
	x41_2_0_batch_pg=x41_2_0_batch_gamma;
	float(*x41_2_0_batch_pb)[32];
	x41_2_0_batch_pb=x41_2_0_batch_beta;
	float(*x41_2_0_batch_pm)[32];
	x41_2_0_batch_pm=x41_2_0_batch_moving_mean;
	float(*x41_2_0_batch_pv)[32];
	x41_2_0_batch_pv=x41_2_0_batch_moving_variance;
	x41_2_0_batch = BatchNormalization(x41_2_0_conv, &x41_2_0_batch_pg, &x41_2_0_batch_pb, &x41_2_0_batch_pm, &x41_2_0_batch_pv, 0);
	Tensor* x41_2_0_relu;
	x41_2_0_relu = ReLU_activation(x41_2_0_batch, 0);
	Tensor* x41_3_conv_up;
	x41_3_conv_up = Conv(x41_2_0_relu, _x41_3_conv_up, linear_activation, 0);
	Tensor* x41_3_batch;
	float(*x41_3_batch_pg)[128];
	x41_3_batch_pg=x41_3_batch_gamma;
	float(*x41_3_batch_pb)[128];
	x41_3_batch_pb=x41_3_batch_beta;
	float(*x41_3_batch_pm)[128];
	x41_3_batch_pm=x41_3_batch_moving_mean;
	float(*x41_3_batch_pv)[128];
	x41_3_batch_pv=x41_3_batch_moving_variance;
	x41_3_batch = BatchNormalization(x41_3_conv_up, &x41_3_batch_pg, &x41_3_batch_pb, &x41_3_batch_pm, &x41_3_batch_pv, 0);
	Tensor* x41_3_relu;
	x41_3_relu = ReLU_activation(x41_3_batch, 0);
	Tensor* x41_4_shortcut;
	x41_4_shortcut = Conv(x41_Maxpool, _x41_4_shortcut, linear_activation, 0);
	Tensor* x41_4_relu;
	x41_4_relu = ReLU_activation(x41_3_relu, 0);
	Tensor* x41_4_batch;
	float(*x41_4_batch_pg)[128];
	x41_4_batch_pg=x41_4_batch_gamma;
	float(*x41_4_batch_pb)[128];
	x41_4_batch_pb=x41_4_batch_beta;
	float(*x41_4_batch_pm)[128];
	x41_4_batch_pm=x41_4_batch_moving_mean;
	float(*x41_4_batch_pv)[128];
	x41_4_batch_pv=x41_4_batch_moving_variance;
	x41_4_batch = BatchNormalization(x41_4_shortcut, &x41_4_batch_pg, &x41_4_batch_pb, &x41_4_batch_pm, &x41_4_batch_pv, 0);
	Tensor* x41_5_add;
	x41_5_add = Add(x41_4_relu, x41_4_batch, 0);
	Tensor* x41_5_relu;
	x41_5_relu = ReLU_activation(x41_5_add, 0);
	Tensor* x41_batch;
	float(*x41_batch_pg)[128];
	x41_batch_pg=x41_batch_gamma;
	float(*x41_batch_pb)[128];
	x41_batch_pb=x41_batch_beta;
	float(*x41_batch_pm)[128];
	x41_batch_pm=x41_batch_moving_mean;
	float(*x41_batch_pv)[128];
	x41_batch_pv=x41_batch_moving_variance;
	x41_batch = BatchNormalization(x41_5_relu, &x41_batch_pg, &x41_batch_pb, &x41_batch_pm, &x41_batch_pv, 0);
	Tensor* x32_Upsamp;
	x32_Upsamp = UpSample(x41_batch, 1, 2, 0);
	Tensor* x22_Upsamp;
	x22_Upsamp = UpSample(x31_batch, 1, 2, 0);
	Tensor* x32_Concate;
	x32_Concate = Concatenate(x31_batch,x32_Upsamp,0);
	Tensor* x12_Upsamp;
	x12_Upsamp = UpSample(x21_Dropout, 1, 2, 0);
	Tensor* x22_Concate;
	x22_Concate = Concatenate(x21_Dropout,x22_Upsamp,0);
	Tensor* x32_1_conv_down;
	x32_1_conv_down = Conv(x32_Concate, _x32_1_conv_down, linear_activation, 0);
	Tensor* x12_Concate;
	x12_Concate = Concatenate(x11_batch,x12_Upsamp,0);
	Tensor* x22_1_conv_down;
	x22_1_conv_down = Conv(x22_Concate, _x22_1_conv_down, linear_activation, 0);
	Tensor* x32_1_batch;
	float(*x32_1_batch_pg)[16];
	x32_1_batch_pg=x32_1_batch_gamma;
	float(*x32_1_batch_pb)[16];
	x32_1_batch_pb=x32_1_batch_beta;
	float(*x32_1_batch_pm)[16];
	x32_1_batch_pm=x32_1_batch_moving_mean;
	float(*x32_1_batch_pv)[16];
	x32_1_batch_pv=x32_1_batch_moving_variance;
	x32_1_batch = BatchNormalization(x32_1_conv_down, &x32_1_batch_pg, &x32_1_batch_pb, &x32_1_batch_pm, &x32_1_batch_pv, 0);
	Tensor* x12_1_conv_down;
	x12_1_conv_down = Conv(x12_Concate, _x12_1_conv_down, linear_activation, 0);
	Tensor* x22_1_batch;
	float(*x22_1_batch_pg)[8];
	x22_1_batch_pg=x22_1_batch_gamma;
	float(*x22_1_batch_pb)[8];
	x22_1_batch_pb=x22_1_batch_beta;
	float(*x22_1_batch_pm)[8];
	x22_1_batch_pm=x22_1_batch_moving_mean;
	float(*x22_1_batch_pv)[8];
	x22_1_batch_pv=x22_1_batch_moving_variance;
	x22_1_batch = BatchNormalization(x22_1_conv_down, &x22_1_batch_pg, &x22_1_batch_pb, &x22_1_batch_pm, &x22_1_batch_pv, 0);
	Tensor* x32_1_relu;
	x32_1_relu = ReLU_activation(x32_1_batch, 0);
	Tensor* x12_1_batch;
	float(*x12_1_batch_pg)[4];
	x12_1_batch_pg=x12_1_batch_gamma;
	float(*x12_1_batch_pb)[4];
	x12_1_batch_pb=x12_1_batch_beta;
	float(*x12_1_batch_pm)[4];
	x12_1_batch_pm=x12_1_batch_moving_mean;
	float(*x12_1_batch_pv)[4];
	x12_1_batch_pv=x12_1_batch_moving_variance;
	x12_1_batch = BatchNormalization(x12_1_conv_down, &x12_1_batch_pg, &x12_1_batch_pb, &x12_1_batch_pm, &x12_1_batch_pv, 0);
	Tensor* x22_1_relu;
	x22_1_relu = ReLU_activation(x22_1_batch, 0);
	Tensor* x32_2_0_conv;
	x32_2_0_conv = Conv(x32_1_relu, _x32_2_0_conv, linear_activation, 0);
	Tensor* x12_1_relu;
	x12_1_relu = ReLU_activation(x12_1_batch, 0);
	Tensor* x22_2_0_conv;
	x22_2_0_conv = Conv(x22_1_relu, _x22_2_0_conv, linear_activation, 0);
	Tensor* x32_2_0_batch;
	float(*x32_2_0_batch_pg)[16];
	x32_2_0_batch_pg=x32_2_0_batch_gamma;
	float(*x32_2_0_batch_pb)[16];
	x32_2_0_batch_pb=x32_2_0_batch_beta;
	float(*x32_2_0_batch_pm)[16];
	x32_2_0_batch_pm=x32_2_0_batch_moving_mean;
	float(*x32_2_0_batch_pv)[16];
	x32_2_0_batch_pv=x32_2_0_batch_moving_variance;
	x32_2_0_batch = BatchNormalization(x32_2_0_conv, &x32_2_0_batch_pg, &x32_2_0_batch_pb, &x32_2_0_batch_pm, &x32_2_0_batch_pv, 0);
	Tensor* x12_2_0_conv;
	x12_2_0_conv = Conv(x12_1_relu, _x12_2_0_conv, linear_activation, 0);
	Tensor* x22_2_0_batch;
	float(*x22_2_0_batch_pg)[8];
	x22_2_0_batch_pg=x22_2_0_batch_gamma;
	float(*x22_2_0_batch_pb)[8];
	x22_2_0_batch_pb=x22_2_0_batch_beta;
	float(*x22_2_0_batch_pm)[8];
	x22_2_0_batch_pm=x22_2_0_batch_moving_mean;
	float(*x22_2_0_batch_pv)[8];
	x22_2_0_batch_pv=x22_2_0_batch_moving_variance;
	x22_2_0_batch = BatchNormalization(x22_2_0_conv, &x22_2_0_batch_pg, &x22_2_0_batch_pb, &x22_2_0_batch_pm, &x22_2_0_batch_pv, 0);
	Tensor* x32_2_0_relu;
	x32_2_0_relu = ReLU_activation(x32_2_0_batch, 0);
	Tensor* x12_2_0_batch;
	float(*x12_2_0_batch_pg)[4];
	x12_2_0_batch_pg=x12_2_0_batch_gamma;
	float(*x12_2_0_batch_pb)[4];
	x12_2_0_batch_pb=x12_2_0_batch_beta;
	float(*x12_2_0_batch_pm)[4];
	x12_2_0_batch_pm=x12_2_0_batch_moving_mean;
	float(*x12_2_0_batch_pv)[4];
	x12_2_0_batch_pv=x12_2_0_batch_moving_variance;
	x12_2_0_batch = BatchNormalization(x12_2_0_conv, &x12_2_0_batch_pg, &x12_2_0_batch_pb, &x12_2_0_batch_pm, &x12_2_0_batch_pv, 0);
	Tensor* x22_2_0_relu;
	x22_2_0_relu = ReLU_activation(x22_2_0_batch, 0);
	Tensor* x32_3_conv_up;
	x32_3_conv_up = Conv(x32_2_0_relu, _x32_3_conv_up, linear_activation, 0);
	Tensor* x12_2_0_relu;
	x12_2_0_relu = ReLU_activation(x12_2_0_batch, 0);
	Tensor* x22_3_conv_up;
	x22_3_conv_up = Conv(x22_2_0_relu, _x22_3_conv_up, linear_activation, 0);
	Tensor* x32_3_batch;
	float(*x32_3_batch_pg)[64];
	x32_3_batch_pg=x32_3_batch_gamma;
	float(*x32_3_batch_pb)[64];
	x32_3_batch_pb=x32_3_batch_beta;
	float(*x32_3_batch_pm)[64];
	x32_3_batch_pm=x32_3_batch_moving_mean;
	float(*x32_3_batch_pv)[64];
	x32_3_batch_pv=x32_3_batch_moving_variance;
	x32_3_batch = BatchNormalization(x32_3_conv_up, &x32_3_batch_pg, &x32_3_batch_pb, &x32_3_batch_pm, &x32_3_batch_pv, 0);
	Tensor* x12_3_conv_up;
	x12_3_conv_up = Conv(x12_2_0_relu, _x12_3_conv_up, linear_activation, 0);
	Tensor* x22_3_batch;
	float(*x22_3_batch_pg)[32];
	x22_3_batch_pg=x22_3_batch_gamma;
	float(*x22_3_batch_pb)[32];
	x22_3_batch_pb=x22_3_batch_beta;
	float(*x22_3_batch_pm)[32];
	x22_3_batch_pm=x22_3_batch_moving_mean;
	float(*x22_3_batch_pv)[32];
	x22_3_batch_pv=x22_3_batch_moving_variance;
	x22_3_batch = BatchNormalization(x22_3_conv_up, &x22_3_batch_pg, &x22_3_batch_pb, &x22_3_batch_pm, &x22_3_batch_pv, 0);
	Tensor* x32_3_relu;
	x32_3_relu = ReLU_activation(x32_3_batch, 0);
	Tensor* x32_4_shortcut;
	x32_4_shortcut = Conv(x32_Concate, _x32_4_shortcut, linear_activation, 0);
	Tensor* x12_3_batch;
	float(*x12_3_batch_pg)[16];
	x12_3_batch_pg=x12_3_batch_gamma;
	float(*x12_3_batch_pb)[16];
	x12_3_batch_pb=x12_3_batch_beta;
	float(*x12_3_batch_pm)[16];
	x12_3_batch_pm=x12_3_batch_moving_mean;
	float(*x12_3_batch_pv)[16];
	x12_3_batch_pv=x12_3_batch_moving_variance;
	x12_3_batch = BatchNormalization(x12_3_conv_up, &x12_3_batch_pg, &x12_3_batch_pb, &x12_3_batch_pm, &x12_3_batch_pv, 0);
	Tensor* x22_3_relu;
	x22_3_relu = ReLU_activation(x22_3_batch, 0);
	Tensor* x22_4_shortcut;
	x22_4_shortcut = Conv(x22_Concate, _x22_4_shortcut, linear_activation, 0);
	Tensor* x32_4_relu;
	x32_4_relu = ReLU_activation(x32_3_relu, 0);
	Tensor* x32_4_batch;
	float(*x32_4_batch_pg)[64];
	x32_4_batch_pg=x32_4_batch_gamma;
	float(*x32_4_batch_pb)[64];
	x32_4_batch_pb=x32_4_batch_beta;
	float(*x32_4_batch_pm)[64];
	x32_4_batch_pm=x32_4_batch_moving_mean;
	float(*x32_4_batch_pv)[64];
	x32_4_batch_pv=x32_4_batch_moving_variance;
	x32_4_batch = BatchNormalization(x32_4_shortcut, &x32_4_batch_pg, &x32_4_batch_pb, &x32_4_batch_pm, &x32_4_batch_pv, 0);
	Tensor* x12_3_relu;
	x12_3_relu = ReLU_activation(x12_3_batch, 0);
	Tensor* x12_4_shortcut;
	x12_4_shortcut = Conv(x12_Concate, _x12_4_shortcut, linear_activation, 0);
	Tensor* x22_4_relu;
	x22_4_relu = ReLU_activation(x22_3_relu, 0);
	Tensor* x22_4_batch;
	float(*x22_4_batch_pg)[32];
	x22_4_batch_pg=x22_4_batch_gamma;
	float(*x22_4_batch_pb)[32];
	x22_4_batch_pb=x22_4_batch_beta;
	float(*x22_4_batch_pm)[32];
	x22_4_batch_pm=x22_4_batch_moving_mean;
	float(*x22_4_batch_pv)[32];
	x22_4_batch_pv=x22_4_batch_moving_variance;
	x22_4_batch = BatchNormalization(x22_4_shortcut, &x22_4_batch_pg, &x22_4_batch_pb, &x22_4_batch_pm, &x22_4_batch_pv, 0);
	Tensor* x32_5_add;
	x32_5_add = Add(x32_4_relu, x32_4_batch, 0);
	Tensor* x12_4_relu;
	x12_4_relu = ReLU_activation(x12_3_relu, 0);
	Tensor* x12_4_batch;
	float(*x12_4_batch_pg)[16];
	x12_4_batch_pg=x12_4_batch_gamma;
	float(*x12_4_batch_pb)[16];
	x12_4_batch_pb=x12_4_batch_beta;
	float(*x12_4_batch_pm)[16];
	x12_4_batch_pm=x12_4_batch_moving_mean;
	float(*x12_4_batch_pv)[16];
	x12_4_batch_pv=x12_4_batch_moving_variance;
	x12_4_batch = BatchNormalization(x12_4_shortcut, &x12_4_batch_pg, &x12_4_batch_pb, &x12_4_batch_pm, &x12_4_batch_pv, 0);
	Tensor* x22_5_add;
	x22_5_add = Add(x22_4_relu, x22_4_batch, 0);
	Tensor* x32_5_relu;
	x32_5_relu = ReLU_activation(x32_5_add, 0);
	Tensor* x12_5_add;
	x12_5_add = Add(x12_4_relu, x12_4_batch, 0);
	Tensor* x22_5_relu;
	x22_5_relu = ReLU_activation(x22_5_add, 0);
	Tensor* x32_batch;
	float(*x32_batch_pg)[64];
	x32_batch_pg=x32_batch_gamma;
	float(*x32_batch_pb)[64];
	x32_batch_pb=x32_batch_beta;
	float(*x32_batch_pm)[64];
	x32_batch_pm=x32_batch_moving_mean;
	float(*x32_batch_pv)[64];
	x32_batch_pv=x32_batch_moving_variance;
	x32_batch = BatchNormalization(x32_5_relu, &x32_batch_pg, &x32_batch_pb, &x32_batch_pm, &x32_batch_pv, 0);
	Tensor* x12_5_relu;
	x12_5_relu = ReLU_activation(x12_5_add, 0);
	Tensor* x22_batch;
	float(*x22_batch_pg)[32];
	x22_batch_pg=x22_batch_gamma;
	float(*x22_batch_pb)[32];
	x22_batch_pb=x22_batch_beta;
	float(*x22_batch_pm)[32];
	x22_batch_pm=x22_batch_moving_mean;
	float(*x22_batch_pv)[32];
	x22_batch_pv=x22_batch_moving_variance;
	x22_batch = BatchNormalization(x22_5_relu, &x22_batch_pg, &x22_batch_pb, &x22_batch_pm, &x22_batch_pv, 0);
	Tensor* x23_Upsamp;
	x23_Upsamp = UpSample(x32_batch, 1, 2, 0);
	Tensor* x12_batch;
	float(*x12_batch_pg)[16];
	x12_batch_pg=x12_batch_gamma;
	float(*x12_batch_pb)[16];
	x12_batch_pb=x12_batch_beta;
	float(*x12_batch_pm)[16];
	x12_batch_pm=x12_batch_moving_mean;
	float(*x12_batch_pv)[16];
	x12_batch_pv=x12_batch_moving_variance;
	x12_batch = BatchNormalization(x12_5_relu, &x12_batch_pg, &x12_batch_pb, &x12_batch_pm, &x12_batch_pv, 0);
	Tensor* x13_Upsamp;
	x13_Upsamp = UpSample(x22_batch, 1, 2, 0);
	Tensor* x23_Concate;
	x23_Concate = Concatenate(x21_Dropout,x22_batch,0);
	x23_Concate = Concatenate(x23_Concate,x23_Upsamp,0);
	Tensor* x13_Concate;
	x13_Concate = Concatenate(x11_batch,x12_batch,0);
	x13_Concate = Concatenate(x13_Concate,x13_Upsamp,0);
	Tensor* x23_1_conv_down;
	x23_1_conv_down = Conv(x23_Concate, _x23_1_conv_down, linear_activation, 0);
	Tensor* x13_1_conv_down;
	x13_1_conv_down = Conv(x13_Concate, _x13_1_conv_down, linear_activation, 0);
	Tensor* x23_1_batch;
	float(*x23_1_batch_pg)[8];
	x23_1_batch_pg=x23_1_batch_gamma;
	float(*x23_1_batch_pb)[8];
	x23_1_batch_pb=x23_1_batch_beta;
	float(*x23_1_batch_pm)[8];
	x23_1_batch_pm=x23_1_batch_moving_mean;
	float(*x23_1_batch_pv)[8];
	x23_1_batch_pv=x23_1_batch_moving_variance;
	x23_1_batch = BatchNormalization(x23_1_conv_down, &x23_1_batch_pg, &x23_1_batch_pb, &x23_1_batch_pm, &x23_1_batch_pv, 0);
	Tensor* x13_1_batch;
	float(*x13_1_batch_pg)[4];
	x13_1_batch_pg=x13_1_batch_gamma;
	float(*x13_1_batch_pb)[4];
	x13_1_batch_pb=x13_1_batch_beta;
	float(*x13_1_batch_pm)[4];
	x13_1_batch_pm=x13_1_batch_moving_mean;
	float(*x13_1_batch_pv)[4];
	x13_1_batch_pv=x13_1_batch_moving_variance;
	x13_1_batch = BatchNormalization(x13_1_conv_down, &x13_1_batch_pg, &x13_1_batch_pb, &x13_1_batch_pm, &x13_1_batch_pv, 0);
	Tensor* x23_1_relu;
	x23_1_relu = ReLU_activation(x23_1_batch, 0);
	Tensor* x13_1_relu;
	x13_1_relu = ReLU_activation(x13_1_batch, 0);
	Tensor* x23_2_0_conv;
	x23_2_0_conv = Conv(x23_1_relu, _x23_2_0_conv, linear_activation, 0);
	Tensor* x13_2_0_conv;
	x13_2_0_conv = Conv(x13_1_relu, _x13_2_0_conv, linear_activation, 0);
	Tensor* x23_2_0_batch;
	float(*x23_2_0_batch_pg)[8];
	x23_2_0_batch_pg=x23_2_0_batch_gamma;
	float(*x23_2_0_batch_pb)[8];
	x23_2_0_batch_pb=x23_2_0_batch_beta;
	float(*x23_2_0_batch_pm)[8];
	x23_2_0_batch_pm=x23_2_0_batch_moving_mean;
	float(*x23_2_0_batch_pv)[8];
	x23_2_0_batch_pv=x23_2_0_batch_moving_variance;
	x23_2_0_batch = BatchNormalization(x23_2_0_conv, &x23_2_0_batch_pg, &x23_2_0_batch_pb, &x23_2_0_batch_pm, &x23_2_0_batch_pv, 0);
	Tensor* x13_2_0_batch;
	float(*x13_2_0_batch_pg)[4];
	x13_2_0_batch_pg=x13_2_0_batch_gamma;
	float(*x13_2_0_batch_pb)[4];
	x13_2_0_batch_pb=x13_2_0_batch_beta;
	float(*x13_2_0_batch_pm)[4];
	x13_2_0_batch_pm=x13_2_0_batch_moving_mean;
	float(*x13_2_0_batch_pv)[4];
	x13_2_0_batch_pv=x13_2_0_batch_moving_variance;
	x13_2_0_batch = BatchNormalization(x13_2_0_conv, &x13_2_0_batch_pg, &x13_2_0_batch_pb, &x13_2_0_batch_pm, &x13_2_0_batch_pv, 0);
	Tensor* x23_2_0_relu;
	x23_2_0_relu = ReLU_activation(x23_2_0_batch, 0);
	Tensor* x13_2_0_relu;
	x13_2_0_relu = ReLU_activation(x13_2_0_batch, 0);
	Tensor* x23_3_conv_up;
	x23_3_conv_up = Conv(x23_2_0_relu, _x23_3_conv_up, linear_activation, 0);
	Tensor* x13_3_conv_up;
	x13_3_conv_up = Conv(x13_2_0_relu, _x13_3_conv_up, linear_activation, 0);
	Tensor* x23_3_batch;
	float(*x23_3_batch_pg)[32];
	x23_3_batch_pg=x23_3_batch_gamma;
	float(*x23_3_batch_pb)[32];
	x23_3_batch_pb=x23_3_batch_beta;
	float(*x23_3_batch_pm)[32];
	x23_3_batch_pm=x23_3_batch_moving_mean;
	float(*x23_3_batch_pv)[32];
	x23_3_batch_pv=x23_3_batch_moving_variance;
	x23_3_batch = BatchNormalization(x23_3_conv_up, &x23_3_batch_pg, &x23_3_batch_pb, &x23_3_batch_pm, &x23_3_batch_pv, 0);
	Tensor* x13_3_batch;
	float(*x13_3_batch_pg)[16];
	x13_3_batch_pg=x13_3_batch_gamma;
	float(*x13_3_batch_pb)[16];
	x13_3_batch_pb=x13_3_batch_beta;
	float(*x13_3_batch_pm)[16];
	x13_3_batch_pm=x13_3_batch_moving_mean;
	float(*x13_3_batch_pv)[16];
	x13_3_batch_pv=x13_3_batch_moving_variance;
	x13_3_batch = BatchNormalization(x13_3_conv_up, &x13_3_batch_pg, &x13_3_batch_pb, &x13_3_batch_pm, &x13_3_batch_pv, 0);
	Tensor* x23_3_relu;
	x23_3_relu = ReLU_activation(x23_3_batch, 0);
	Tensor* x23_4_shortcut;
	x23_4_shortcut = Conv(x23_Concate, _x23_4_shortcut, linear_activation, 0);
	Tensor* x13_3_relu;
	x13_3_relu = ReLU_activation(x13_3_batch, 0);
	Tensor* x13_4_shortcut;
	x13_4_shortcut = Conv(x13_Concate, _x13_4_shortcut, linear_activation, 0);
	Tensor* x23_4_relu;
	x23_4_relu = ReLU_activation(x23_3_relu, 0);
	Tensor* x23_4_batch;
	float(*x23_4_batch_pg)[32];
	x23_4_batch_pg=x23_4_batch_gamma;
	float(*x23_4_batch_pb)[32];
	x23_4_batch_pb=x23_4_batch_beta;
	float(*x23_4_batch_pm)[32];
	x23_4_batch_pm=x23_4_batch_moving_mean;
	float(*x23_4_batch_pv)[32];
	x23_4_batch_pv=x23_4_batch_moving_variance;
	x23_4_batch = BatchNormalization(x23_4_shortcut, &x23_4_batch_pg, &x23_4_batch_pb, &x23_4_batch_pm, &x23_4_batch_pv, 0);
	Tensor* x13_4_relu;
	x13_4_relu = ReLU_activation(x13_3_relu, 0);
	Tensor* x13_4_batch;
	float(*x13_4_batch_pg)[16];
	x13_4_batch_pg=x13_4_batch_gamma;
	float(*x13_4_batch_pb)[16];
	x13_4_batch_pb=x13_4_batch_beta;
	float(*x13_4_batch_pm)[16];
	x13_4_batch_pm=x13_4_batch_moving_mean;
	float(*x13_4_batch_pv)[16];
	x13_4_batch_pv=x13_4_batch_moving_variance;
	x13_4_batch = BatchNormalization(x13_4_shortcut, &x13_4_batch_pg, &x13_4_batch_pb, &x13_4_batch_pm, &x13_4_batch_pv, 0);
	Tensor* x23_5_add;
	x23_5_add = Add(x23_4_relu, x23_4_batch, 0);
	Tensor* x13_5_add;
	x13_5_add = Add(x13_4_relu, x13_4_batch, 0);
	Tensor* x23_5_relu;
	x23_5_relu = ReLU_activation(x23_5_add, 0);
	Tensor* x13_5_relu;
	x13_5_relu = ReLU_activation(x13_5_add, 0);
	Tensor* x23_batch;
	float(*x23_batch_pg)[32];
	x23_batch_pg=x23_batch_gamma;
	float(*x23_batch_pb)[32];
	x23_batch_pb=x23_batch_beta;
	float(*x23_batch_pm)[32];
	x23_batch_pm=x23_batch_moving_mean;
	float(*x23_batch_pv)[32];
	x23_batch_pv=x23_batch_moving_variance;
	x23_batch = BatchNormalization(x23_5_relu, &x23_batch_pg, &x23_batch_pb, &x23_batch_pm, &x23_batch_pv, 0);
	Tensor* x13_batch;
	float(*x13_batch_pg)[16];
	x13_batch_pg=x13_batch_gamma;
	float(*x13_batch_pb)[16];
	x13_batch_pb=x13_batch_beta;
	float(*x13_batch_pm)[16];
	x13_batch_pm=x13_batch_moving_mean;
	float(*x13_batch_pv)[16];
	x13_batch_pv=x13_batch_moving_variance;
	x13_batch = BatchNormalization(x13_5_relu, &x13_batch_pg, &x13_batch_pb, &x13_batch_pm, &x13_batch_pv, 0);
	Tensor* x14_Upsamp;
	x14_Upsamp = UpSample(x23_batch, 1, 2, 0);
	Tensor* x14_Concate;
	x14_Concate = Concatenate(x11_batch,x12_batch,0);
	x14_Concate = Concatenate(x14_Concate,x13_batch,0);
	x14_Concate = Concatenate(x14_Concate,x14_Upsamp,0);
	Tensor* x14_1_conv_down;
	x14_1_conv_down = Conv(x14_Concate, _x14_1_conv_down, linear_activation, 0);
	Tensor* x14_1_batch;
	float(*x14_1_batch_pg)[4];
	x14_1_batch_pg=x14_1_batch_gamma;
	float(*x14_1_batch_pb)[4];
	x14_1_batch_pb=x14_1_batch_beta;
	float(*x14_1_batch_pm)[4];
	x14_1_batch_pm=x14_1_batch_moving_mean;
	float(*x14_1_batch_pv)[4];
	x14_1_batch_pv=x14_1_batch_moving_variance;
	x14_1_batch = BatchNormalization(x14_1_conv_down, &x14_1_batch_pg, &x14_1_batch_pb, &x14_1_batch_pm, &x14_1_batch_pv, 0);
	Tensor* x14_1_relu;
	x14_1_relu = ReLU_activation(x14_1_batch, 0);
	Tensor* x14_2_0_conv;
	x14_2_0_conv = Conv(x14_1_relu, _x14_2_0_conv, linear_activation, 0);
	Tensor* x14_2_0_batch;
	float(*x14_2_0_batch_pg)[4];
	x14_2_0_batch_pg=x14_2_0_batch_gamma;
	float(*x14_2_0_batch_pb)[4];
	x14_2_0_batch_pb=x14_2_0_batch_beta;
	float(*x14_2_0_batch_pm)[4];
	x14_2_0_batch_pm=x14_2_0_batch_moving_mean;
	float(*x14_2_0_batch_pv)[4];
	x14_2_0_batch_pv=x14_2_0_batch_moving_variance;
	x14_2_0_batch = BatchNormalization(x14_2_0_conv, &x14_2_0_batch_pg, &x14_2_0_batch_pb, &x14_2_0_batch_pm, &x14_2_0_batch_pv, 0);
	Tensor* x14_2_0_relu;
	x14_2_0_relu = ReLU_activation(x14_2_0_batch, 0);
	Tensor* x14_3_conv_up;
	x14_3_conv_up = Conv(x14_2_0_relu, _x14_3_conv_up, linear_activation, 0);
	Tensor* x14_3_batch;
	float(*x14_3_batch_pg)[16];
	x14_3_batch_pg=x14_3_batch_gamma;
	float(*x14_3_batch_pb)[16];
	x14_3_batch_pb=x14_3_batch_beta;
	float(*x14_3_batch_pm)[16];
	x14_3_batch_pm=x14_3_batch_moving_mean;
	float(*x14_3_batch_pv)[16];
	x14_3_batch_pv=x14_3_batch_moving_variance;
	x14_3_batch = BatchNormalization(x14_3_conv_up, &x14_3_batch_pg, &x14_3_batch_pb, &x14_3_batch_pm, &x14_3_batch_pv, 0);
	Tensor* x14_3_relu;
	x14_3_relu = ReLU_activation(x14_3_batch, 0);
	Tensor* x14_4_shortcut;
	x14_4_shortcut = Conv(x14_Concate, _x14_4_shortcut, linear_activation, 0);
	Tensor* x14_4_relu;
	x14_4_relu = ReLU_activation(x14_3_relu, 0);
	Tensor* x14_4_batch;
	float(*x14_4_batch_pg)[16];
	x14_4_batch_pg=x14_4_batch_gamma;
	float(*x14_4_batch_pb)[16];
	x14_4_batch_pb=x14_4_batch_beta;
	float(*x14_4_batch_pm)[16];
	x14_4_batch_pm=x14_4_batch_moving_mean;
	float(*x14_4_batch_pv)[16];
	x14_4_batch_pv=x14_4_batch_moving_variance;
	x14_4_batch = BatchNormalization(x14_4_shortcut, &x14_4_batch_pg, &x14_4_batch_pb, &x14_4_batch_pm, &x14_4_batch_pv, 0);
	Tensor* x14_5_add;
	x14_5_add = Add(x14_4_relu, x14_4_batch, 0);
	Tensor* x14_5_relu;
	x14_5_relu = ReLU_activation(x14_5_add, 0);
	Tensor* x14_batch;
	float(*x14_batch_pg)[16];
	x14_batch_pg=x14_batch_gamma;
	float(*x14_batch_pb)[16];
	x14_batch_pb=x14_batch_beta;
	float(*x14_batch_pm)[16];
	x14_batch_pm=x14_batch_moving_mean;
	float(*x14_batch_pv)[16];
	x14_batch_pv=x14_batch_moving_variance;
	x14_batch = BatchNormalization(x14_5_relu, &x14_batch_pg, &x14_batch_pb, &x14_batch_pm, &x14_batch_pv, 0);
	Tensor* main_output_1;
	main_output_1 = Conv(x12_batch, _main_output_1, sigmoid_activation, 0);
	Tensor* main_output_2;
	main_output_2 = Conv(x13_batch, _main_output_2, sigmoid_activation, 0);
	Tensor* main_output_3;
	main_output_3 = Conv(x14_batch, _main_output_3, sigmoid_activation, 0);


	//print_tensor(main_input);


	/******************  释放内存  ******************/
	free_ConvLayer(_x11_1_conv_down);
	free_ConvLayer(_x11_2_0_conv);
	free_ConvLayer(_x11_3_conv_up);
	free_ConvLayer(_x11_4_shortcut);
	free_ConvLayer(_x21_1_conv_down);
	free_ConvLayer(_x21_2_0_conv);
	free_ConvLayer(_x21_3_conv_up);
	free_ConvLayer(_x21_4_shortcut);
	free_ConvLayer(_x31_1_conv_down);
	free_ConvLayer(_x31_2_0_conv);
	free_ConvLayer(_x31_3_conv_up);
	free_ConvLayer(_x31_4_shortcut);
	free_ConvLayer(_x41_1_conv_down);
	free_ConvLayer(_x41_2_0_conv);
	free_ConvLayer(_x41_3_conv_up);
	free_ConvLayer(_x41_4_shortcut);
	free_ConvLayer(_x32_1_conv_down);
	free_ConvLayer(_x22_1_conv_down);
	free_ConvLayer(_x12_1_conv_down);
	free_ConvLayer(_x32_2_0_conv);
	free_ConvLayer(_x22_2_0_conv);
	free_ConvLayer(_x12_2_0_conv);
	free_ConvLayer(_x32_3_conv_up);
	free_ConvLayer(_x22_3_conv_up);
	free_ConvLayer(_x12_3_conv_up);
	free_ConvLayer(_x32_4_shortcut);
	free_ConvLayer(_x22_4_shortcut);
	free_ConvLayer(_x12_4_shortcut);
	free_ConvLayer(_x23_1_conv_down);
	free_ConvLayer(_x13_1_conv_down);
	free_ConvLayer(_x23_2_0_conv);
	free_ConvLayer(_x13_2_0_conv);
	free_ConvLayer(_x23_3_conv_up);
	free_ConvLayer(_x13_3_conv_up);
	free_ConvLayer(_x23_4_shortcut);
	free_ConvLayer(_x13_4_shortcut);
	free_ConvLayer(_x14_1_conv_down);
	free_ConvLayer(_x14_2_0_conv);
	free_ConvLayer(_x14_3_conv_up);
	free_ConvLayer(_x14_4_shortcut);
	free_ConvLayer(_main_output_1);
	free_ConvLayer(_main_output_2);
	free_ConvLayer(_main_output_3);

	printf("\nHello World!\n");
	return 0;
}